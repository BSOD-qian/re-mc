function vercheck(){
    var xhr, data, version;
    xhr = new XMLHttpRequest();
    xhr.open("get", "https://remc.rth1.one/versiondev.json");
    xhr.onreadystatechange = function(){
        if (xhr.readyState === 4) {
            data = JSON.parse(xhr.responseText);
            version = data.version;
            if (version !== "0.17 Beta 2"){
                mdui.snackbar({
                    message: '检测到更新，版本' + data.version + '，请去KOOK频道下载最新预览版',
                    buttonText: '刷新',
                    onButtonClick: function(){
                      location.reload();
                    }
                  });
            };
        }
    }
    xhr.send();
};
window.onload = vercheck();
setInterval("vercheck();", 60000);